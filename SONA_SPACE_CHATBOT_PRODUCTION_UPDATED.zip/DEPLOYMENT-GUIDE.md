﻿# SONA SPACE - cPanel Deployment with AI Chatbot

## New Features
- AI Chatbot with OpenAI GPT-4o-mini
- Real-time chat via Socket.IO
- Enhanced email notifications
- Return rejection with supplier contact

## Deployment Steps

1. Upload files to cPanel public_html
2. Run setup-chatbot.sql in MySQL
3. Update .env with your OpenAI API key
4. Setup Node.js App in cPanel:
   - Startup file: app.js
   - Node.js version: 16+
5. Install dependencies: npm install --production
6. Start application

## Required Environment Variables
**IMPORTANT:** Update these in your .env file:

### Core Configuration:
- OPENAI_API_KEY: Your OpenAI API key for chatbot
- DB_PASS: Your database password
- EMAIL_PASS: Gmail app password

### URL Configuration (Required for MoMo Payment):
- API_BASE_URL: Your backend domain (e.g., https://api.sonaspace.com)
- SITE_URL: Your frontend domain (e.g., https://sonaspace.com)

**Note:** After successful MoMo payment, users will be automatically redirected to:
`SITE_URL/dat-hang-thanh-cong/ORDER_ID`

This matches your frontend route: `/dat-hang-thanh-cong/:orderHash`

### Example .env configuration:
```env
API_BASE_URL=https://api.yourdomain.com
SITE_URL=https://yourdomain.com
OPENAI_API_KEY=sk-your-openai-key
DB_PASS=your_db_password
EMAIL_PASS=your_gmail_app_password
```

## Testing
- API: GET /api/products
- Chatbot: WebSocket connection to /socket.io/
- Email: Order notifications working

## Support
Phone: 0705768791
Email: nguyenhongthai0802@gmail.com
