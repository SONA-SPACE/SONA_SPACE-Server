﻿-- Chatbot Database Setup
CREATE TABLE IF NOT EXISTS chatbot_context (
    id INT AUTO_INCREMENT PRIMARY KEY,
    context_text TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO chatbot_context (context_text) VALUES 
('Báº¡n lÃ  trá»£ lÃ½ AI thÃ¢n thiá»‡n cá»§a Sona Space - chuyÃªn gia ná»™i tháº¥t cao cáº¥p. Há»— trá»£ khÃ¡ch hÃ ng vá» sáº£n pháº©m, Ä‘Æ¡n hÃ ng, vÃ  dá»‹ch vá»¥. LiÃªn há»‡: 0705768791')
ON DUPLICATE KEY UPDATE context_text = VALUES(context_text);
