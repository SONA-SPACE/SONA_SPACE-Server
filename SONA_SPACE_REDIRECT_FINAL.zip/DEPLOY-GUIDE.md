# 🚀 SONA SPACE - HƯỚNG DẪN DEPLOY LÊN cPANEL

## 📦 File đã được chuẩn bị

✅ **File ZIP:** `SONA_SPACE_cPanel.zip`
✅ **Thư mục build:** `cpanel-build/`

## 📋 Nội dung build bao gồm:

### 🔧 File cốt lõi:
- `app.js` - Ứng dụng chính
- `package.json` - Dependencies (chỉ production)
- `package-lock.json` - Lock file cho dependencies
- `.env` - Cấu hình môi trường production
- `.htaccess` - Cấu hình Apache cho Node.js

### 📁 Thư mục chính:
- `bin/` - Server startup scripts
- `config/` - Database và cấu hình
- `middleware/` - Authentication, upload, etc.
- `models/` - Database models
- `routes/` - API endpoints
- `services/` - Email service, API service
- `template/` - Email templates (order, return, rejection, etc.)
- `views/` - EJS templates
- `public/` - Static files (CSS, JS, images, fonts)
- `migrations/` - Database migration scripts

## 🔧 HƯỚNG DẪN DEPLOY CHI TIẾT

### Bước 1: Upload Files
1. **Đăng nhập cPanel**
2. **Mở File Manager**
3. **Chọn thư mục:** `public_html` (hoặc tạo subfolder như `public_html/api/`)
4. **Upload file:** `SONA_SPACE_cPanel.zip`
5. **Extract:** Click chuột phải → Extract

### Bước 2: Cài đặt Node.js App
1. **Trong cPanel:** Software → **Setup Node.js App**
2. **Create App:**
   - **Node.js Version:** Latest (16+ recommended)
   - **Application Mode:** Production
   - **Application Root:** `public_html` (hoặc subfolder bạn chọn)
   - **Application URL:** Domain hoặc subdomain của bạn
   - **Application Startup File:** `app.js`
   - **Passenger log file:** Để mặc định

### Bước 3: Environment Variables
**Trong Node.js App settings, thêm các biến:**
```
NODE_ENV=production
PORT=3501
DB_HOST=fur.timefortea.io.vn
DB_PORT=3306
DB_USER=thainguyen0802
DB_PASS=[YOUR_DB_PASSWORD]
DB_NAME=fur_timefortea_io_vn
EMAIL_USER=sonaspace.furniture@gmail.com
EMAIL_PASS=rndo lwgk rvqu bqpj
JWT_SECRET=sona_space_secret_key_2024_production
```

### Bước 4: Cài Dependencies
**Trong Terminal (hoặc SSH):**
```bash
cd /home/[username]/public_html
npm install --production
```

### Bước 5: Cấu hình Database
1. **Cập nhật file `.env`** với thông tin database đúng
2. **Kiểm tra kết nối database:**
   - Host: `fur.timefortea.io.vn`
   - User: `thainguyen0802`
   - Database: `fur_timefortea_io_vn`
   - Port: `3306`

### Bước 6: Start Application
1. **Trong cPanel Node.js App:** Click **"Start App"**
2. **Kiểm tra status:** App should show "Running"
3. **Check logs:** Xem log file để đảm bảo không có lỗi

## ✅ KIỂM TRA DEPLOYMENT

### Test các endpoint chính:
```bash
# Products API
GET https://yourdomain.com/api/products

# Categories API  
GET https://yourdomain.com/api/categories

# Orders API (cần authentication)
GET https://yourdomain.com/api/orders

# Auth API
POST https://yourdomain.com/api/auth/login
```

### Test Email System:
- Order confirmation emails
- Return approval emails  
- Return rejection emails
- Coupon creation emails

## 🚨 TROUBLESHOOTING

### Lỗi thường gặp:

1. **"Application failed to start"**
   - Kiểm tra syntax error trong code
   - Xem Passenger log file
   - Đảm bảo `app.js` exists và executable

2. **Database connection error**
   - Kiểm tra `.env` file
   - Verify database credentials
   - Test database connection

3. **Email không gửi được**
   - Kiểm tra `EMAIL_USER` và `EMAIL_PASS`
   - Verify Gmail app password
   - Check firewall/port restrictions

4. **Static files không load**
   - Kiểm tra `public/` folder permissions
   - Verify `.htaccess` configuration

### Debug commands:
```bash
# Check app status
pm2 status

# View logs
pm2 logs

# Restart app
pm2 restart all

# Check dependencies
npm list --production
```

## 📞 SUPPORT

**Liên hệ kỹ thuật:**
- Email: nguyenhongthai0802@gmail.com
- Phone: 0705768791
- Giờ hỗ trợ: 8:00-17:00 (T2-T6)

## 🎯 TÍNH NĂNG ĐÃ BAO GỒM

✅ **Order Management System**
- Tạo, cập nhật, hủy đơn hàng
- Tracking trạng thái đơn hàng
- Order history và details

✅ **Return/Refund System**  
- Yêu cầu trả hàng
- Approval/rejection workflow
- Automatic coupon creation (20% discount)
- Email notifications cho mọi trạng thái

✅ **Email Notifications**
- Order confirmation
- Return approval với coupon
- Return rejection với supplier contact
- Professional templates

✅ **User Authentication**
- JWT-based authentication
- Admin/user role management
- Secure API endpoints

✅ **Product Catalog**
- Product management
- Categories, variants, colors
- Image upload (Cloudinary)
- Search và filtering

✅ **Payment Integration**
- Multiple payment methods
- Payment status tracking
- Revenue reporting

✅ **Admin Dashboard**
- Order management
- User management  
- Product management
- Analytics và reports

---

**🎉 DEPLOYMENT COMPLETED**  
**📅 Built:** August 15, 2025  
**🏷️ Version:** Production 1.0.0  
**🔧 Environment:** cPanel Ready
